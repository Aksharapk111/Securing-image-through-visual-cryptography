# -*- coding: utf-8 -*-
"""
Created on Sat Dec 23 12:37:09 2023

@author: hp
"""

from flask import Flask,render_template,request
import pickle
import numpy as np
import random
from face import video
app=Flask(__name__)



@app.route('/')
def home():
    return render_template('home.html')
@app.route('/predict', methods=['POST'])

def predict():
    try:

        path=request.values['image']
        path="test/"+path
        fo = open(path, "rb")
        image=fo.read()
        fo.close()
        image=bytearray(image)
        key=random.randint(0,256)
        for index , value in enumerate(image):
            image[index] = value^key
        fo=open("result/enc.jpg","wb")
        imageRes="result/enc.jpg"
        fo.write(image)
        fo.close()
        print(key)
        return render_template('home.html',x=key)
    except:
        return render_template('home.html')

 
    
    
@app.route('/decrypt', methods=['POST'])
def decrypt():
    try:

        images=request.values['images']
        keys=request.values['keys']
        key=int(keys)
        path="result/"+images
        fo = open(path, "rb")
        image=fo.read()
        fo.close()
        image=bytearray(image)
        for index , value in enumerate(image):
            image[index] = value^key
        fo=open("result/dec.jpg","wb")
        imageRes="result/dec.jpg"
        fo.write(image)
        fo.close()
        return imageRes
    except:

        return render_template('home.html')

@app.route('/facerec', methods=['POST'])
def facerec():
    try:
        print("working")
        video()
    except:
        return render_template('home.html')

    
    
    
if __name__=='__main__':
    app.run()